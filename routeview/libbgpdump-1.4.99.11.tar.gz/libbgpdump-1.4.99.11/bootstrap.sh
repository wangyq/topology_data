#!/bin/sh

autoheader
autoconf
